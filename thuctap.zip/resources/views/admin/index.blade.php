@extends('layouts.navigation')

@section('content')
    Trang admin
@endsection