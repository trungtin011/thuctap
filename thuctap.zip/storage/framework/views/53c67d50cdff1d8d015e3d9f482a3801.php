


<?php $__env->startSection('content'); ?>
    <h2 class="py-4 text-2xl font-bold text-center">Lịch sử nạp thẻ</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 text-sm">
            <thead class="bg-gray-200">
                <tr>
                    <th class="border px-4 py-2">Nhà mạng</th>
                    <th class="border px-4 py-2">Số serial</th>
                    <th class="border px-4 py-2">Mã thẻ</th>
                    <th class="border px-4 py-2">Mệnh giá</th>
                    <th class="border px-4 py-2">Thực nhận</th>
                    <th class="border px-4 py-2">Trạng thái</th>
                    <th class="border px-4 py-2">Thời gian</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($card->telco); ?></td>
                        <td class="border px-4 py-2"><?php echo e($card->card_serial); ?></td>
                        <td class="border px-4 py-2"><?php echo e($card->card_code); ?></td>
                        <td class="border px-4 py-2"><?php echo e(number_format($card->amount)); ?> đ</td>
                        <td class="border px-4 py-2"><?php echo e($card->response ? number_format($card->response) . ' đ' : '-'); ?></td>
                        <td class="border px-4 py-2">
                            <?php if($card->status == 'pending'): ?>
                                <span class="text-yellow-600">Đang xử lý</span>
                            <?php elseif($card->status == 'success'): ?>
                                <span class="text-green-600">Thành công</span>
                            <?php else: ?>
                                <span class="text-red-600">Thất bại</span>
                            <?php endif; ?>
                        </td>
                        <td class="border px-4 py-2"><?php echo e($card->created_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($cards->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\thuctap\thuctap\resources\views\User\history.blade.php ENDPATH**/ ?>